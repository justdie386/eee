local dia = require("discordia")
local dcmd = require("discordia-slash")
local commandType = dia.enums.appCommandType
local optionType = dia.enums.appCommandOptionType
enlist = require("./func.lua")
dia.extensions()
local enums = dia.enums
local client = dia.Client{
    logFile = 'mybot.log',
    cacheAllMembers = true,
}:useApplicationCommands()
local function initializeCommands(guild)
           local command, err = client:createGuildApplicationCommand(guild.id, {
        type = commandType.chatInput,
        name = "dm",
        description = ".",
        options = {
            {
                type = optionType.subCommand,
                name = "from",
                description = "input your id",
                options = {
                    {
                        type = optionType.string,
                        name = "role",
                        description = "role that will get dmed",
                        required = true,
                        autocomplete = true,
                    },
                        {
                        type = optionType.string,
                        name = "code",
                        description = "waterloo code",
                        required = true,
                        autocomplete = true,
                        }
                    
                },
            },
        },
    })
    end
local function initializeCommands2(guild)
           local command, err = client:createGuildApplicationCommand(guild.id, {
        type = commandType.chatInput,
        name = "role",
        description = ".",
        options = {
                        {
                        type = optionType.user,
                        name = "recruit",
                        description = "user you want to recruit",
                        required = true,
                        autocomplete = true,
                        }
              },
    })
    end
client:on("ready", function()
        for guild in client.guilds:iter() do
             --for some reason we need to use this to actually load the slash command or smt otherwise it won't create itself
            initializeCommands(guild)
            initializeCommands2(guild)
      end
end)

function log(id, interaction, args)
    local channel = client:getChannel(id)
    channel:send("<@"..interaction.member.id..">".." - ".."<@"..args.this.recruit.id..">")
    end

client:on("slashCommand", function(interaction, command, args)
        if interaction.data.name == "dm" then
                        interaction:reply("Done!")
            for member in interaction.guild.members:iter() do
            if member:hasRole(args.from.role) then
                    member:send("Join the battle, CODE: "..args.from.code)
end
 end
            end
    if interaction.data.name == "role" then
        ResultChannel = client:getChannel(interaction.channel.id)
        if ResultChannel.id == "862958840604786718" then --42nd
            enlist.r42(interaction, args)
            log("862773879261102090", interaction, args)
        elseif ResultChannel.id == "862956971127472138" then --35th
            enlist.r35(interaction, args)
            log("1012697310943264820", interaction, args)
        elseif ResultChannel.id == "862971827072139284" then --23rd
            enlist.r23(interaction, args)
               log("862961583914483742", interaction, args)
        elseif ResultChannel.id == "1031576851447033856" then --50th
            enlist.r50(interaction, args)
      		log("1034731024594260028", interaction, args)
        elseif ResultChannel.id == "1022991502344986654" then --60th
            enlist.r60(interaction, args)
			log("1022992371799052389", interaction, args)
        elseif ResultChannel.id == "808739332013424650" then --kgl
            enlist.rkgl(interaction, args)
            log("935835116423483402", interaction, args)
        else do
        interaction:reply("This command has been used in the wrong channel")
        end
        end
        end
end)
client:on("messageCreate", function(msg)
       if msg.content == "hidden" then
       for member in msg.guild.members:iter() do
            if member:hasRole("1010651979229442079") then
        member:send("hey dw im just testing the auto dm feature, no i didn't dm everyone, only people with 35th staff role dw buddy")
end
 end
   end
 end)
client:run("Bot OTMwMjc5OTcxOTgzODgwMjAz.GsNDip.W5IL_82uvpnTd4JQDCCyt9o1_5Cevvajw4X0yI")