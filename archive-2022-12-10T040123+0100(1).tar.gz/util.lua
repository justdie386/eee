local discordia = require("discordia")
local client = discordia.Client()
local util = {}

function util.log(recruiter, recruit, succ, err, interaction)
    if succ then
        client:info(recruiter.name.." successfully ranked "..recruit.name)
        interaction:reply("Successfully ranked "..recruit.name)
        if interaction.channel.id == "862971827072139284" then --23rd
        local channel = "862961583914483742"
        channel:send(recruiter.name.." successfully ranked "..recruit.name)
        elseif interaction.channel.id == "862956971127472138" then --35th
            local channel = getChannel("1012697310943264820")
        elseif interaction.channel.id == "862958840604786718" then --42nd
        local channel = getChannel("862773879261102090")
        channel:send(recruiter.name.." successfully ranked "..recruit.name)
        elseif interaction.channel.id == "1031576851447033856" then --50th
        local channel = getChannel("1034731024594260028")
        channel:send(recruiter.name.." successfully ranked "..recruit.name)
        elseif interaction.channel.id == "1022991502344986654" then --60th
            local channel = getChannel("1022992371799052389")
        channel:send(recruiter.name.." successfully ranked "..recruit.name)
        elseif interaction.channel.id == "808739332013424650" then --KGL
            local channel = getChannel("935835116423483402")
        channel:send(recruiter.name.." successfully ranked "..recruit.name)
            end
    elseif err then
        interaction:reply("We had a problem: "..err)
        client:error("Failed to rank: "..err)
    end
end
function util.role(user, role1, role2, role3, role4, role5, role6)
    local gave = 0
    if role1 ~= nil then
        local succ, err = user:addRole(role1)
        local gave = gave + 1
        util.log()
    end
    if role2 ~= nil then
        local succ, err = user:addRole(role2)
        local gave = gave + 1

    end
    if role3 ~= nil then
        user:addRole(role3)
        local gave = gave + 1

    end
    if role4 ~= nil then
        user:addRole(role4)
        local gave = gave + 1

    end
    if role5 ~= nil then
        user:addRole(role5)
        local gave = gave + 1

    end
    if role6 ~= nil then
        user:addRole(role6)
        local gave = gave + 1

    end
    client:info(gave.." roles has been given to "..recruit.name)
end
return util